import { test, expect } from "@playwright/test";
import { loginPage } from "../pages/LoginPage";
import registerData from "../test-data/registerData.json";

test("Logout from an authenticated account", async ({ page }) => {
    const loginpage = new loginPage(page);
    const loggedInAs = page.getByText(`Logged in as ${registerData.name}`);

    await loginpage.navigateTo();
    await page.locator('a[href="/login"]').click();
    await loginpage.loginToAccount(registerData.email, registerData.password);
    await expect(loggedInAs).toBeVisible();

    await loginpage.logoutFromAccount();
    await expect(page.locator('a[href="/login"]')).toBeVisible();
    await expect(loggedInAs).toHaveCount(0);
});