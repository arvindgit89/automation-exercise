import { Page, expect } from "@playwright/test";

export class BasePage {
  protected page: Page;
  constructor(page: Page) {
    this.page = page;
  }
  async navigateTo() {
    await this.page.goto("/");
  }
  async getPageTitle() {
    return this.page.title();
  }
}
