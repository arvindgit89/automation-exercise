import { test } from "@playwright/test";
import { loginPage } from "../pages/LoginPage";

test("User Login", async ({ page }) => {
   const loginpage = new loginPage(page);
   await loginpage.navigateTo();
   await page.locator('a[href="/login"]').click();
   await loginpage.loginToAccount();
});