import {Page, expect} from "@playwright/test";
import { BasePage } from "../pages/BasePage";
import registerData from "../test-data/registerData.json";

export class loginPage extends BasePage {

    constructor(page: Page) {
        super(page);
    }
    private emailInput = this.page.locator('input[data-qa="login-email"]');
    private passwordInput = this.page.locator('input[data-qa="login-password"]')
    private loginButton = this.page.locator('button[data-qa="login-button"]');

    async loginToAccount() {
        await this.emailInput.fill(registerData.email);
        await this.passwordInput.fill(registerData.password);
        await this.loginButton.click();
        await expect(this.page).toHaveURL(/\/account\/$/);

    }

}