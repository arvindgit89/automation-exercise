import { test, expect } from "@playwright/test";
import { signupPage } from "../pages/RegisterPage";

test("Register a new account", async ({ page }) => {
    const email = `arvind${Date.now()}${Math.random().toString(36).slice(2)}@gmail.com`;
    const signuppage = new signupPage(page);

    await signuppage.navigateTo();
    await page.locator('a[href="/login"]').click();
    await signuppage.newUserRegistration(email);
    await signuppage.completeRegistration();
    await expect(page.locator('[data-qa="account-created"]')).toContainText(/ACCOUNT CREATED!/i);
});
