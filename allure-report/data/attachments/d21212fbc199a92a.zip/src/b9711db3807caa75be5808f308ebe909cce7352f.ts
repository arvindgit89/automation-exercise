import { Page, expect } from "@playwright/test";
//import configData from "../config/environment";
export class BasePage {
  protected page: Page;
  constructor(page: Page) {
    this.page = page;
  }
  async navigateTo() {
    await this.page.goto("/");
  }
  async getPageTitle() {
    return this.page.title();
  }
}
