import { test, expect } from "@playwright/test";
import { signupPage } from "../pages/RegisterPage";
import { loginPage } from "../pages/LoginPage";
import registerData from "../test-data/registerData.json";

test("User can register, logout, and login with the same credentials", async ({ page }) => {
    const email = `arvind${Date.now()}${Math.random().toString(36).slice(2)}@gmail.com`;
    const signuppage = new signupPage(page);
    const loginpage = new loginPage(page);

    await signuppage.navigateTo();
    await page.locator('a[href="/login"]').click();
    await signuppage.newUserRegistration(email);
    await signuppage.completeRegistration();
    await expect(page.locator('[data-qa="account-created"]')).toContainText("Account Created!");
    await signuppage.continueAfterRegistration();

    await loginpage.logoutFromAccount();
    await page.locator('a[href="/login"]').click();
    await loginpage.loginToAccount(email, registerData.password);
    await expect(page.getByText(`Logged in as ${registerData.name}`)).toBeVisible();
});