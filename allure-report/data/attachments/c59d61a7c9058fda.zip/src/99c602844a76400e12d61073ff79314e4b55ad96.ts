import {test, expect} from "@playwright/test";
import { signupPage } from "../pages/RegisterPage";

test("User Registration", async ({ page }) => {
    const signuppage = new signupPage(page);
    await signuppage.newUserRegistration();
});