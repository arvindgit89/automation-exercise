import{Page, expect} from "@playwright/test";
import { BasePage } from "../pages/BasePage";
import registerData from "../test-data/registerData.json";

export class signupPage extends BasePage {

    constructor(page: Page) {
        super(page);
    }

    private nameInput = this.page.locator('input[data-qa="signup-name"]');
    private emailInput = this.page.locator('input[data-qa="signup-email"]');
    private signupButton = this.page.locator('button[data-qa="signup-button"]');

    async newUserRegistration() {
        await this.nameInput.fill(registerData.name);
        await this.emailInput.fill(registerData.email);
        await this.signupButton.click();
        expect(this.page).toHaveURL("/signup/");

    }
}
