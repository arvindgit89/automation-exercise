import { test, expect } from "@playwright/test";
import { loginPage } from "../pages/LoginPage";
import registerData from "../test-data/registerData.json";

test("Login with registerData credentials", async ({ page }) => {
    const loginpage = new loginPage(page);

    await loginpage.navigateTo();
    await page.locator('a[href="/login"]').click();
    await loginpage.loginToAccount(registerData.email, registerData.password);

    await expect(page.getByText(`Logged in as ${registerData.name}`)).toBeVisible();
});