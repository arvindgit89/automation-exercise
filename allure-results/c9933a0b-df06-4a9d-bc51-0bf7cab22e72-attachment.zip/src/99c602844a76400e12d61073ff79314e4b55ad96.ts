import { test, expect } from "@playwright/test";
import { randomUUID } from "node:crypto";
import { signupPage } from "../pages/RegisterPage";
import { loginPage } from "../pages/LoginPage";
import registerData from "../test-data/registerData.json";

test("User can register, logout, and login with the same credentials", async ({ page }) => {
    const email = `arvind.${randomUUID()}@gmail.com`;
    const signuppage = new signupPage(page);
    const loginpage = new loginPage(page);

    await signuppage.navigateTo();
    await page.locator('a[href="/login"]').click();
    await signuppage.newUserRegistration(email);
    await signuppage.completeRegistration();
    await expect(page.locator('[data-qa="account-created"]')).toContainText("ACCOUNT CREATED!");
    await signuppage.continueAfterRegistration();

    await loginpage.logoutFromAccount();
    await page.locator('a[href="/login"]').click();
    await loginpage.loginToAccount(email, registerData.password);
    await expect(page.getByText(`Logged in as ${registerData.name}`)).toBeVisible();
});