import { test, expect } from "@playwright/test";
import { signupPage } from "../pages/RegisterPage";
import { loginPage } from "../pages/LoginPage";
import registerData from "../test-data/registerData.json";

test("Logout from an authenticated account", async ({ page }) => {
    const email = `arvind${Date.now()}${Math.random().toString(36).slice(2)}@gmail.com`;
    const signuppage = new signupPage(page);
    const loginpage = new loginPage(page);
    const loggedInAs = page.getByText(`Logged in as ${registerData.name}`);

    await signuppage.navigateTo();
    await page.locator('a[href="/login"]').click();
    await signuppage.newUserRegistration(email);
    await signuppage.completeRegistration();
    await expect(page.locator('[data-qa="account-created"]')).toContainText(/ACCOUNT CREATED!/i);
    await signuppage.continueAfterRegistration();
    await expect(loggedInAs).toBeVisible();

    await loginpage.logoutFromAccount();
    await expect(page.locator('a[href="/login"]')).toBeVisible();
    await expect(loggedInAs).toHaveCount(0);
});